﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
	public float PlayerMoveSpeed = 1;

	[HideInInspector]
	public bool CanMove = true;

	[HideInInspector]
	public Animator Anim;

	public Anim_PlayerMove Anim_PlayerMoveScript;

	private CharacterController PlayerController;
	private bool IsMoving;

	void MovePlayer()
	{
		Vector3 PlayerDirection = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical"));
		this.transform.rotation = Quaternion.LookRotation(PlayerDirection);
		PlayerController.SimpleMove(PlayerDirection * PlayerMoveSpeed);
		Anim_PlayerMoveScript.Move();
	}

	// Use this for initialization
	void Start()
	{
		Anim = GetComponent<Animator>();
		PlayerController = GetComponent<CharacterController>();
	}

	// Update is called once per frame
	void Update()
	{
		IsMoving = (Input.GetAxisRaw("Vertical") != 0 || Input.GetAxisRaw("Horizontal") != 0) ? true : false;

		if (CanMove && IsMoving)
			MovePlayer();
		else
			Anim_PlayerMoveScript.Stop();
	}

	void FixedUpdate()
	{

	}
}