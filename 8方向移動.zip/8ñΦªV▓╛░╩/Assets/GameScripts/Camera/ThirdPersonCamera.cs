﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThirdPersonCamera : MonoBehaviour
{
	public GameObject Player;

	// Use this for initialization
	void Start()
	{

	}

	// Update is called once per frame
	void Update()
	{
		this.transform.position = new Vector3(Player.transform.position.x, Player.transform.position.y + 3.6f, Player.transform.position.z - 4.9f);
	}

	void FixedUpdate()
	{

	}
}