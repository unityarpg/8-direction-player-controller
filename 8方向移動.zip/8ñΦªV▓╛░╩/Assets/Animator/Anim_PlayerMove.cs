﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Anim_PlayerMove : MonoBehaviour
{
	private Animator Anim;

	public void Move()
	{
		Anim.SetBool("IsMoving", true);
	}

	public void Stop()
	{
		Anim.SetBool("IsMoving", false);
	}

	// Use this for initialization
	void Start()
	{
		GameObject Player = GameObject.Find("GameObjectRef").GetComponent<GameObjectRef>().Player;
		//PlayerMove PlayerMoveScript = Player.GetComponent<PlayerMove>();

		Anim = Player.GetComponent<Animator>();
	}

	// Update is called once per frame
	void Update()
	{

	}
}